# Ocean Animal Speller

Android spelling game for phones and tablets.

## Build an APK with GitHub

1. Create a new GitHub repository, for example `OceanAnimalSpeller`.
2. Upload the contents of this project to the repository.
3. Open the **Actions** tab.
4. Select **Build Ocean Animal Speller APK**.
5. Click **Run workflow**.
6. When the workflow finishes, open the run and download the `OceanAnimalSpeller-debug-apk` artifact.
7. Extract the downloaded ZIP and install `app-debug.apk` on an Android phone or tablet.

The GitHub Actions workflow builds the APK in the cloud and stores it as a workflow artifact.
