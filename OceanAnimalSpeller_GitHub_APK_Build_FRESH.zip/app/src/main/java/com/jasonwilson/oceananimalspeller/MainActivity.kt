package com.jasonwilson.oceananimalspeller

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

data class Animal(val name: String, val emoji: String)

private val animals = listOf(
    Animal("FISH", "🐟"),
    Animal("SEAL", "🦭"),
    Animal("CRAB", "🦀"),
    Animal("SHARK", "🦈"),
    Animal("WHALE", "🐋"),
    Animal("SQUID", "🦑"),
    Animal("CLOWNFISH", "🐠"),
    Animal("BLUE TANG", "🐟"),
    Animal("TURTLE", "🐢"),
    Animal("DOLPHIN", "🐬"),
    Animal("OCTOPUS", "🐙"),
    Animal("STARFISH", "⭐"),
    Animal("SEAHORSE", "🌊"),
    Animal("MANTA RAY", "🌊"),
    Animal("JELLYFISH", "🪼"),
    Animal("SEALION", "🦭"),
    Animal("STINGRAY", "🌊"),
    Animal("HAMMERHEAD", "🦈"),
    Animal("SWORDFISH", "🐟")
)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.UK
        }
        setContent { OceanAnimalSpellerApp(::speak) }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "animal")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun OceanAnimalSpellerApp(speak: (String) -> Unit) {
    var started by remember { mutableStateOf(false) }
    var index by remember { mutableStateOf(0) }
    var answer by remember { mutableStateOf("") }
    var stars by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf("") }

    val animal = animals[index]
    val letters = remember(animal.name) {
        animal.name.filter { it != ' ' }.toList().shuffled()
    }

    fun submitLetter(letter: Char) {
        val target = animal.name.filter { it != ' ' }
        val pos = answer.length
        if (pos < target.length && letter == target[pos]) {
            answer += letter
            message = ""
            if (answer.length == target.length) {
                stars++
                message = "⭐ Great job!"
                speak(animal.name)
            }
        } else {
            message = "Try another letter!"
            speak(letter.toString())
        }
    }

    MaterialTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFFE3F7FF)
        ) {
            if (!started) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("🌊", fontSize = 72.sp)
                    Text(
                        "OCEAN ANIMAL",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF006994)
                    )
                    Text(
                        "SPELLER",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF006994)
                    )
                    Spacer(Modifier.height(20.dp))
                    Text("Spell the ocean animals!", fontSize = 20.sp)
                    Spacer(Modifier.height(32.dp))
                    Button(
                        onClick = {
                            started = true
                            speak("Let's spell some ocean animals!")
                        },
                        modifier = Modifier.fillMaxWidth().height(64.dp),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text("🐠  PLAY", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Ocean Animals", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("⭐ $stars", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("${index + 1} / ${animals.size}", fontSize = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(animal.emoji, fontSize = 100.sp)
                    Text("What animal is this?", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))

                    val spaced = animal.name.map { if (it == ' ') ' ' else '_' }
                    Text(
                        if (animal.name.contains(" "))
                            answer.padEnd(animal.name.count { it != ' ' }, '_').chunked(1).joinToString(" ") 
                        else
                            answer.padEnd(animal.name.length, '_').toCharArray().joinToString(" "),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 3.sp
                    )

                    Spacer(Modifier.height(8.dp))
                    Text(message, fontSize = 18.sp, color = Color(0xFF006994), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))

                    if (answer.length == animal.name.count { it != ' ' }) {
                        Button(
                            onClick = {
                                index = (index + 1) % animals.size
                                answer = ""
                                message = ""
                                speak(animals[(index + 1) % animals.size].name)
                            },
                            modifier = Modifier.fillMaxWidth().height(55.dp)
                        ) {
                            Text("NEXT ANIMAL ➜", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        val rows = letters.chunked(5)
                        rows.forEach { row ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(7.dp, Alignment.CenterHorizontally)
                            ) {
                                row.forEach { ch ->
                                    Button(
                                        onClick = { submitLetter(ch) },
                                        modifier = Modifier.size(58.dp),
                                        shape = RoundedCornerShape(14.dp),
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text(ch.toString(), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { speak(animal.name) }) {
                            Text("🔊 Hear the animal", fontSize = 17.sp)
                        }
                    }
                }
            }
        }
    }
}
